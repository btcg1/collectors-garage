COLLECTOR'S GARAGE, 2 CAROUSELL LISTINGS + WEBSITE PACKAGE

You requested TWO listings, not ten:
  1. High value TLV: LD22, LD23, LD24 (3 cars)
  2. Everything else: 37 cars

Use the Carousell copy-ready text at the ZIP root, and the files in CAROUSELL_READY for photos. Each listing has one main cover. The 37-car listing has seven additional category photo sheets so all 37 items are visible in only 8 uploads. Individual crops are included too.

SITE_UPDATE/loose-diecast.html is the replacement page for your website. SITE_UPDATE/photos and SITE_UPDATE/covers supply its images. SITE_UPDATE/apply_homepage_banner.py adds a bold bulk-buyer announcement at the top of the existing main index.html while preserving all other main-site listings.

PUBLISHING: Direct GitHub write access is blocked (403), so site deployment is not completed. Read SITE_UPDATE/DEPLOY_GUIDE.txt for the exact steps.

All 40 prices match the latest independent revised audit and are negotiable. The private combined asking totals are not disclosed on the website.
