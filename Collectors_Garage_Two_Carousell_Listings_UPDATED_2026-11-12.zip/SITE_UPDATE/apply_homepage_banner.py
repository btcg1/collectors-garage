#!/usr/bin/env python3
"""Insert a prominent banner below the homepage navigation without replacing the website."""
from pathlib import Path
import sys
from datetime import datetime
TARGET=Path(sys.argv[1]) if len(sys.argv)>1 else Path('index.html')
if not TARGET.exists():raise SystemExit(f'Cannot find {TARGET}. Run this in the website root or pass the path to index.html.')
original=TARGET.read_text(encoding='utf-8')
if 'cg-bulk-banner__inside' in original:
 print('Banner already exists. Homepage unchanged.')
 raise SystemExit(0)
if '</head>' not in original or '</header>' not in original:
 raise SystemExit('Did not find expected </head> and </header>. No changes made.')
BANNER_STYLE='<style id="cg-bulk-banner-style">\n.cg-bulk-banner{max-width:1360px;margin:18px auto 0;padding:0 25px}\n.cg-bulk-banner__inside{background:linear-gradient(125deg,#293e32,#18303a);border:2px solid #e7f47e;border-radius:16px;padding:22px 26px;box-shadow:0 8px 30px #0005}\n.cg-bulk-banner__inside strong{display:block;color:#e7f47e;font-size:clamp(28px,4.4vw,54px);font-weight:900;line-height:1.1;letter-spacing:-.045em}\n.cg-bulk-banner__inside p{color:#edf7ed;font-size:clamp(13px,1.6vw,19px);line-height:1.55;margin:9px 0 0}\n@media(max-width:680px){.cg-bulk-banner{padding:0 12px;margin-top:12px}.cg-bulk-banner__inside{padding:16px}}\n</style>'
BANNER_HTML='<!-- Collector\'s Garage bulk discount banner -->\n<section class="cg-bulk-banner" aria-label="Bulk-buyer discounts"><div class="cg-bulk-banner__inside"><strong>BIG DISCOUNTS FOR BULK BUYERS</strong><p>Buying several items? Mix any models across the collection and ask me for a generous bulk deal. Every price is negotiable.</p></div></section>\n'
TARGET.with_suffix('.html.before_bulk_banner.bak').write_text(original,encoding='utf-8')
updated=original.replace('</head>',BANNER_STYLE+'\n</head>',1).replace('</header>','</header>\n'+BANNER_HTML,1)
TARGET.write_text(updated,encoding='utf-8')
print('Homepage banner inserted:',TARGET)
