# Collector's Garage: two-listing regrouping, 12 November 2026

This folder includes a fully rebuilt two-listing loose-diecast page, the homepage bulk discount patch, original cropped product photos, and Carousell-ready photo sheets.

## Group totals (private only)

- Listing 01: LD22, LD23, LD24. **3** cars. Sum of individually listed asks: **S$142**. Cheapest individual: S$32.
- Listing 02: 37 cars, all other LD IDs. Sum of individually listed asks: **S$256**. Cheapest individual: S$3.
- Full inventory: **40** cars, combined individual asks **S$398**. These are NOT target batch offer prices and are NOT displayed publicly.

No prices were raised or lowered compared with the user's latest independent audit. Prior listing 05 supplied the two Mercedes and prior listing 06 supplied the red Cosmo. The rest are all consolidated into the second listing.

## Photo distribution

- TLV listing: one cover + three individual photo crops.
- Other listing: one cover + seven category sheets showing 37 cars. All 37 individual photo crops also supplied for buyers who request close-ups.
- Cover photos are layouts using actual photos; no product retouching or digital cleaning. The original JPEG crops are preserved.

## Explicit condition details

- Heavy, caked-on dust across all loose models, not thoroughly cleaned.
- LD22/LD23 two 190Es worn. One has a missing side mirror, not yet identified which.
- Blue-looking glazing on Mercedes not proven to be damage.
- LD14 AE86 is missing all wheels.
- LD09 Porsche has bonnet paint chips.
- LD26 MX-5 has custom wheels.
- Several makers/scales (gacha, Civic EF9, Initial D) remain unverified, and their names remain qualified where appropriate.

## Website

The main homepage retains its existing listings. apply_homepage_banner.py adds a large bulk-discount banner at the top without replacing homepage content. The `loose-diecast.html` page now renders EXACTLY two group sections. 

GitHub writes through the connected integration returned HTTP 403, so this zip is the ready-to-publish handoff and is NOT confirmation that the live site changed.
